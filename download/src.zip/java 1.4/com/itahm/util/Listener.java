package com.itahm.util;

public interface Listener {
	
	public void onEvent(Object caller, Object ...event);
}
