package com.itahm.util;
import java.util.UUID;

public class KeyGen {

	public static void main(String[] args) {
		System.out.println(UUID.randomUUID().toString().toUpperCase());
	}

}
