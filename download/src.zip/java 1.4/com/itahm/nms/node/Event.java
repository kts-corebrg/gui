package com.itahm.nms.node;

public enum Event {
	PING, SNMP, RESOURCE, CLOSE;
}
